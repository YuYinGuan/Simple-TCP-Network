Yu Yin Guan
yguan5@ucsc.edu
CE 156

This Program I have in source will not work and will stop at the part of connecting.
There are test programs I wrote for different stages of programming I was in, they are a bit messy

I was able to get pthread working by itself, Server with I/O multiplex, and other general stuff. 
Did not implement the message and protocol for getting file because I was stucked.

Note: I was not able to get into the ssh server on thursday because it was down, just a side note.