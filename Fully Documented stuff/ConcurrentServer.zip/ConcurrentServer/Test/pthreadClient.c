#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/types.h>  //Socket data types
#include <sys/socket.h> //socket(), connect(), send(), and recv()
#include <netinet/in.h> //IP Socket data types
#include <arpa/inet.h>  //for sockaddr_in and inet_addr()

struct thread_info{    /* Used as argument to thread_start() */
   pthread_t   thread_id;        /* ID returned by pthread_create() */
   char *      thread_num;       /* Application-defined thread # */
   int         sockfd;
   char *      fileName;
   char *      stringArg;
};

static void * thread_start(void *arg){
   struct thread_info *threadInfo = arg;
   
   char *recvBuff;
  
   if(write(threadInfo->sockfd, threadInfo->stringArg, strlen(threadInfo->stringArg)) < 0);
      printf("in thread, write errored #%d\n", threadInfo->thread_num);
   read(threadInfo->sockfd, recvBuff, 1024);
   printf("I got: %s\n", recvBuff);
   close(threadInfo->sockfd);
   pthread_exit((void*) arg);
}

int main(int argc, char* argv[]){

   printf("begins\n");
   
   struct sockaddr_in servAddr;
   
   int numCon = atoi(argv[3]);
   int serNum;
   struct thread_info *pThreads;
   pthread_t testThreads[numCon];
   
   pThreads = calloc(numCon, sizeof(struct thread_info));
   
   if (pThreads== NULL){
      fprintf(stderr, "Error : Could not memory for thread_info Structure\n");
      return EXIT_FAILURE;
   }
   
   servAddr.sin_family = AF_INET;
   servAddr.sin_port = htons(atoi(argv[2]));
   servAddr.sin_addr.s_addr = inet_addr(argv[1]);

   printf("on top of forloop\n");
   //reads and stores all IP and Port in the list of servers for later use
   
   
   for(serNum = 0; serNum< numCon; serNum++){
   
      if((pThreads[serNum].sockfd = socket(AF_INET, SOCK_STREAM,0))< 0){
         fprintf(stderr, "Error : Could not create socket #%d \n", serNum);
         return EXIT_FAILURE;
      }
      
      if(connect(pThreads[serNum].sockfd, (struct sockaddr *)&servAddr, sizeof(servAddr))< 0){
         fprintf(stderr, "Error : Connect to socket #%d Failed \n", serNum);
         return EXIT_FAILURE;
      }
      
      printf("forloop #%d\n", serNum);
      char temp =serNum + '0';
      pThreads[serNum].thread_num = &(temp);
      pThreads[serNum].stringArg = "I am thread ";
      
      printf("forloop top of strcat #%d\n", serNum);
      
      //strcat(pThreads[serNum].stringArg, &pThreads[serNum].thread_num);
      
      printf("forloop top of create #%d\n", serNum);
      pthread_create(&pThreads[serNum].thread_id, NULL, thread_start, &pThreads[serNum]);
      printf("forloop End #%d\n", serNum);
      
   }
   
   
   printf("I am here2\n");
   
   for(serNum = 0; serNum< numCon; serNum++){
   
      printf("start wait #%d\n",serNum);
      pthread_join(pThreads[serNum].thread_id, NULL);
      printf("end wait #%d\n",serNum);
      
   }
   
   printf("Main: program completed. Exiting.\n");
   free(pThreads);
   pthread_exit(NULL);
   return 0;
   
}
