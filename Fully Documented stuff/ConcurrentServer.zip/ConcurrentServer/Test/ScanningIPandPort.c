#include<stdio.h>
#include<stdlib.h>
#include <string.h>
#define MAX_LEN 250

int main(int argc, char * argv[]){
   /*setting up the variables needed, scanners, printer, etc*/
      FILE *in, *outRSSI, *outLQI;
      char line[MAX_LEN];
      char tokenlist[MAX_LEN];
      char* token;
      char RSSI[4] = "RSSI";
      char LQI[4] = "LQI";
      char outNameRSSI[20] = "RSSI";
      char outNameLQI[20] = "LQI";
      int temp, dbm;
      int flag = 0;
      int allFin = 2;
      int x,y;
      int row =0;
      int clmn = 0;
      int RSSIMatrix[30][255];
      int LQIMatrix[30][255];
      
   for(x=0;x<30;x++){
      for(y=0;y<255;y++){
         RSSIMatrix[x][y] = 300;
         LQIMatrix[x][y] = 300;
      }
   }
   /* check command line for correct number of arguments */
   if( argc < 3 ){
       printf("Usage: %s out_type infile .... infile_n\n", argv[0]);
       exit(1);
   }
   
   strcat(outNameRSSI, argv[1]);
   strcat(outNameRSSI, ".csv");
   strcat(outNameLQI, argv[1]);
   strcat(outNameLQI, ".csv");
   
   /* open files for reading and writing */
   outRSSI = fopen(outNameRSSI, "w");
   outLQI = fopen(outNameLQI, "w");
   if(outRSSI==NULL ){
      printf("Unable to open output RSSI file %s for writing\n", outRSSI);
      exit(1);
   }
   if(outLQI==NULL ){
      printf("Unable to open output LQI file %s for writing\n", outLQI);
      exit(1);
   }
   
   while(allFin != argc){
      in = fopen(argv[allFin], "r");
      if( in==NULL ){
         printf("Unable to open input text file %s for reading\n", argv[2]);
         exit(1);
      }
      for(x=2; x<argc; x++){
         fprintf(outLQI, "%s,", argv[x]);
         fprintf(outRSSI, "%s,", argv[x]);
      }
      fprintf(outLQI, "\n");
      fprintf(outRSSI, "\n");
      
      /* read each line of input file, then count and print tokens */
      while(fgets(line, MAX_LEN, in)!= NULL){
         token = strtok(line, ": \n\r");
         while( token!=NULL ){
            if(strcmp(token,LQI)==0){
               token = strtok(NULL, ": \n\r");
               temp = atoi(token);
               if(temp <200){
                  //fprintf(out, "%s,", token);
                  LQIMatrix[clmn][row] = temp;
                  token = strtok(NULL, ": \n\r");
                  token = strtok(NULL, ": \n\r");
                  temp = atoi(token);	
                  if(temp<128){
                     dbm = ((temp/2)-69);
                     //fprintf(outRSSI, "%d\n", dbm);
                     RSSIMatrix[clmn][row] = dbm;
                  }else{
                     dbm = (((temp-256)/2)-69);
                     //fprintf(outRSSI, "%d\n", dbm);
                     RSSIMatrix[clmn][row] = dbm;
                  }
                  row++;
               }
            }
            token = strtok(NULL, ": \n\r");
         }
      }
      row =0;
      clmn++;
      fclose(in);
      allFin++;
   }
   
   for(y=0;y<255;y++){
      for(x=0;x<30;x++){
         if(RSSIMatrix[x][y]!=300){
            fprintf(outRSSI, "%d,", RSSIMatrix[x][y]);
         }   
         if(LQIMatrix[x][y]!=300){
            fprintf(outLQI, "%d,", LQIMatrix[x][y]);
         }
      }
      fprintf(outLQI, "\n");
      fprintf(outRSSI, "\n");
   }
   
   
   fclose(outRSSI);
   fclose(outLQI);
}