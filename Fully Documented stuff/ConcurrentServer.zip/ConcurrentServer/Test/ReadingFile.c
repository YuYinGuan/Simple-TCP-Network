#include <stdio.h>
#include <stdlib.h>

int main(int argc, char* argv[]){
   //file reader pointer
   FILE *inInfo, *inFile, *out;
   char *readBuff = (char*)calloc(50,sizeof(char));
   int bytesRead;
   
   //inInfo = fopen("serverinfo.txt","r");
   inFile = fopen("test.text", "r");

   out = fopen("Testoutput.txt", "w");
   if(inFile==NULL ){
      printf("Unable to open input text inFile for reading\n");
      return EXIT_FAILURE;
   }

   //gets end of file byte
   fseek(inFile, 0, SEEK_END);
   int x = ftell(inFile);
   
   //bytesRead = fread(readBuff, sizeof(char), 20 ,inFile);
   //printf("Bytes read %d\n", bytesRead);
   printf("Bytes read %d\n", x);
   
   printf("readBuff: %s\n", readBuff);
   
   fwrite(readBuff, sizeof(char), 20 ,out);
   
   fclose(inFile);
   fclose(out);
   return 0;
}
