#include <stdio.h>
#include <stdlib.h>
#include <sys/types.h>  //Socket data types
#include <sys/socket.h> //socket(), connect(), send(), and recv()
#include <netinet/in.h> //IP Socket data types
#include <arpa/inet.h>  //for sockaddr_in and inet_addr()
#include <string.h>     //memset()
#include <unistd.h>      
#include <netdb.h>
#include <errno.h>
#include <time.h>
#include <sys/ioctl.h>
#include <signal.h>
#include <sys/wait.h>

int main(int argc, char* argv[]){

   fprintf(stderr, "\r\n/******************Yu Yin's Proxy********************/\r\n");
      
   //Checking Valid # of Arguments
   if(argc != 2){
      fprintf(stderr, "Usuage: ./proxy <port_number>\n");
      return EXIT_FAILURE;
   }
   
   
   
/*****************************Setups of General Variables and Operations**********************/   
   //Variables
   pid_t pid;
   int byte_size = 0;            //counts bytes received
   int listenfd = 0, connfd = 0;       
   struct hostent* host;
   
   //read and write files
   FILE *permitted_sites;
   FILE *logging;
   
   //checking if server list file is able to be opened
   if((permitted_sites = fopen("permitted_sites.txt", "r"))== NULL){
      fprintf(stderr,"ERROR: Unable to open read file.\n");
      return EXIT_FAILURE;       //exit fail if can't open server list
   }
   
   //create and check if file can be written into
   if((logging = fopen("logging.txt", "w"))== NULL){                                          /////////argv[1]
      fprintf(stderr,"ERROR: Unable to open output file.\n");
      return EXIT_FAILURE;    //exit fail if can't write to file
   }
   
   //Setup for a fresh log after new start of proxy
   fprintf(logging,"LOGGING OF ALL HTTP REQUEST HANDLED BY THIS PROXY AFTER STARTUP:\r\n\r\n");
   fclose(logging);
   
   //Create Listening Socket
   listenfd = socket(AF_INET, SOCK_STREAM, 0);
   if(listenfd < 0){
      fprintf(stderr, "Error : Could not create socket \n");
      return EXIT_FAILURE;
   }
   
   //Initializing Proxy Information
   struct sockaddr_in proxy_addr; 
   proxy_addr.sin_family = AF_INET;    
   proxy_addr.sin_addr.s_addr = INADDR_ANY; //what ip to use
   proxy_addr.sin_port = htons(atoi(argv[1]));    
 
   //Binding Information to Socket
   bind(listenfd, (struct sockaddr*)&proxy_addr,sizeof(proxy_addr));

   //Listening on Socket, Blocks
   if(listen(listenfd, 5) < 0){
      fprintf(stderr, "Error: Failed to listen\n");
      return EXIT_FAILURE;
   }
         
   fprintf(stderr, "\r\n/******************Ready to Accept Connections********************/\r\n");
   
   //Persistent connections: 
      //Note that the browser will use persistent connections by default 
      //if it is using HTTP 1.1. In this case, either the client (browser) or the server may initiate 
      //the close. The proxy server must be able to deal with this by closing the connection on 
      //the other side when the TCP connection on one side closes.
   
   
   
   
   
/************************************************Start of the Program**********************************************/   
   while(1){
      
      //accept connection when there is one, purposely block
      connfd = accept(listenfd, (struct sockaddr*)NULL ,NULL);
      if (connfd < 0){
         fprintf(stderr, "Problem in accepting connection\n");
      }
      
      //make new process
      pid = fork();
      if (pid == 0){ //if child
      
      
      
         /****************General Variables************************/
         //Buffers for storing information
         char recvBuff[500];
         char method[50],URL[200],protocol[50], host_name[200],host_path[500];
         int host_port = 0;
         
         //socket and select variables
         int newsocket;             //socket number for listen
         int nready;
         int maxfd = 0;
         int count = 0;
         
         //reading permitted sites variables
         char *token;
         char line[250];
         
         //Flags
         int connectFlag; 
         int permittedFlag = 0;
         int badRequestFlag = 0;
         int reqErrorFlag = 1;
         
         //Variables for Timer of Select
         struct timeval tv;
         tv.tv_sec;
         tv.tv_usec;
         
         //Selection Init and Variables
         fd_set rwset;
         FD_ZERO(&rwset);
         
         //Variables for Logging
         
         //fd for appending new logs
         FILE *loggingChild;
         
         //Date
         time_t rawtime;
         struct tm * timeinfo;
         time ( &rawtime );
         timeinfo = localtime ( &rawtime );
         //timeinfo.tm_hour += 2;
         //timeinfo.tm_min += 15;
         //Type of request and HTTP version, Requesting host name, URI and server address already made in General Variables
         //Action taken and Error
         char *proxyAction;
         char *errorType;
         
         //new connection for connecting to internet
         struct sockaddr_in host_addr;
         host_addr.sin_family = AF_INET;    
         
         //init buffers with 0
         memset(recvBuff, '0',500);
         memset(method, '0' ,50);
         memset(URL, '0' ,200);
         memset(protocol, '0' ,50);
         memset(host_name, '0' ,200);
         memset(host_path, '0' ,500);

         
         /******************* Parsing of Header**********************/
         //Receive Data from browser
         byte_size = recv(connfd,recvBuff,500,0);
         
         //parse the header for method, url, and http version
         if(sscanf(recvBuff, "%s %s %s", method,URL,protocol)!=3){
            //if something is wrong, do not connect and send reply 
            //##### all of these simular structures are used for logging
            if(reqErrorFlag){
               send(connfd, "400 : BAD REQUEST\n", 18, 0);
               errorType = "400 : BAD REQUEST";       //logging info
               proxyAction = "Rejected Bad Request";  //logging info
               badRequestFlag = 1;
               reqErrorFlag = 0;
            }
         }

         //checks if the URL is correctly parsed. If so, set the port appropriately, otherwise, send out BAD REQUEST
         if(strncasecmp(URL, "http://", 7 )==0){
            if(sscanf( URL, "http://%[^:/]:%d%s", host_name, &host_port, host_path ) == 3 ){
               host_addr.sin_port = htons(host_port);    
            }else if(sscanf( URL, "http://%[^/]%s", host_name, host_path ) == 2 ){
               host_addr.sin_port = htons(80);
            }else if( sscanf( URL, "http://%[^:/]:%d", host_name, &host_port ) == 2 ){
               host_addr.sin_port = htons(host_port); 
               *host_path = '\0';
            }else if( sscanf( URL, "http://%[^/]", host_name ) == 1 ){
               host_addr.sin_port = htons(80); 
               *host_path = '\0';
            }else{
               if(reqErrorFlag){
                  send(connfd, "400 : BAD REQUEST\n", 18, 0);
                  errorType = "400 : BAD REQUEST";
                  proxyAction = "Rejected Bad Request";
                  badRequestFlag = 1;
                  reqErrorFlag = 0;
               }
               reqErrorFlag = 0;
            }
         }else{
            if(reqErrorFlag){
               send(connfd, "400 : BAD REQUEST\n", 18, 0);
               errorType = "400 : BAD REQUEST";
               proxyAction = "Rejected Bad Request";
               badRequestFlag = 1;
               reqErrorFlag = 0;
            }
            reqErrorFlag = 0;
         }
         
         /******************Checking of Received Header (Methods & Permitted Site)********************************/
         
         //Checks if it is methods allowed to be handled, if not send out not implemented responds
         if(((strncasecmp(method, "GET", 3)!=0)) && ((strncasecmp(method, "HEAD", 4)!=0)) && ((strncasecmp(method, "POST", 4)!=0))){
            if(reqErrorFlag){
               send(connfd, "501 : NOT IMPLEMENTED\n", 22, 0);
               errorType = "501 : NOT IMPLEMENTED";
               proxyAction = "Header Method Denied";
               reqErrorFlag = 0;
            }
            reqErrorFlag = 0;
         }
         
         //goes to start of the permitted_sites.txt file
         fseek(permitted_sites,0,SEEK_SET);
         
         //check the URL against allowed websites
         while(fgets(line, sizeof(line), permitted_sites)!=NULL){
            token = strtok(line, " \n\r");   //to get rid of the space, \r or \n
            if(strcmp(token, host_name) == 0){
               permittedFlag = 1;
               break;
               //fprintf(stdout, "token == host_name\n");
            }
            //fprintf(stdout, "Read Line From permitted_sites.txt: %s\nstrcmp(token, host_name) = %d\n", line,strcmp(line, host_name));
         }
         
         //check if site is permitted, if not send forbidden URL and set connection flag to be false
         if(permittedFlag == 0){
            if(reqErrorFlag){
               send(connfd, "403 : FORBIDDEN URL\n", 20, 0);
               errorType = "403 : FORBIDDEN URL";
               proxyAction = "Filtered URL";
               reqErrorFlag = 0;
            }
         }
         
         
         /******************Checking of Received Header (Protocols and errors)********************************/
         //check if the protocol is HTTP 1.1 or 1.0, if not send out 400 BAD REQUEST
         if(((strncasecmp(protocol, "HTTP/1.1", 8)==0) || (strncasecmp(protocol, "HTTP/1.0", 8)==0))&&(reqErrorFlag == 1)){
            host = gethostbyname(host_name);
            memcpy(&host_addr.sin_addr, host->h_addr_list[0],sizeof(struct in_addr));
           
            //fprintf(stdout, "I received %d bytes:\n%s\n\nmethod = %s\nURL = %s\nprotocol = %s\nhost_name = %s\nhost_path = %s\n", byte_size,recvBuff, method,URL,protocol,host_name,host_path);
            
            //connect to the requested Site
            newsocket = socket(AF_INET, SOCK_STREAM, 0);
            connectFlag = connect(newsocket, (struct sockaddr*)&host_addr, sizeof(struct sockaddr));
            
            //if connect when wrong, reply to browser and end connection
            if(connectFlag < 0){
               send(connfd, "406 : NOT ACCEPTABLE\n", 21, 0);
               errorType = "406 : NOT ACCEPTABLE";
               proxyAction = "Rejected Bad Request";
               badRequestFlag = 1;
               reqErrorFlag = 0;
               fprintf(stdout, "Error in connecting to remote server\n");
               goto closed;
            }
            
            //debugging tool
            //fprintf(stdout, "\nConnected to %s  IP - %s\n", host_name, inet_ntoa(host_addr.sin_addr));
            
            //send whatever we have right now to server first
            byte_size = send(newsocket, recvBuff, strlen(recvBuff), 0);
            
            //if sending went wrong error out
            if(byte_size<0){
               send(connfd, "404 : Not Found\n", 16, 0);
               errorType = "404 : Not Found";
               proxyAction = "Connection Closed";
               badRequestFlag = 1;
               reqErrorFlag = 0;
               fprintf(stdout, "Error writing to socket:%s \n",strerror(errno));
               goto closed;
            }
            
            //find maxfd for select
            if(newsocket>connfd){
               maxfd = newsocket;
            }else{
               maxfd = connfd;
            }
            
            /**************************Transfer of Files********************************/
            while(1){
               //reset all FD_SET & timeout each time
               FD_SET(connfd, &rwset);
               FD_SET(newsocket, &rwset);
               tv.tv_sec = 10;   //10 second timeout
               tv.tv_usec = 0;
               
               //wait until something from browser or server is available
               nready = select(maxfd +1, &rwset, NULL, NULL,&tv);
               
               //check if error, available, or timeout
               if (nready == -1){
                  perror("select()");
               }else if(nready){           
                   //printf("Data is available now.\n");   //For debugging
               }else{
                  //reply, log, and break out of while loop if timed out
                  send(connfd, "408 : Request Timeout\n", 22, 0);
                  errorType = "408 : Request Timeout";
                  proxyAction = "Connection Closed";
                  badRequestFlag = 1;
                  reqErrorFlag = 0;
                  goto closed;
               }
               
               
               /*______________________________Browser to Server__________________________________*/
               //If there is still stuff from browser, send it over, break out of while when received 1
               if(FD_ISSET(connfd, &rwset)){
                  //check amount of avaible data in buffer
                  ioctl(connfd, FIONREAD, &count);
                  
                  //while there is data
                  while(count>0){
                     //init buffer and recv data
                     memset(recvBuff, '0',500);
                     byte_size = recv(connfd,recvBuff,500,0);
                     
                     //if recv 0 bytes, end connection
                     if(byte_size ==0){
                        goto beforeClosed;
                     }
                     
                     //else send the data received
                     byte_size = send(newsocket, recvBuff, strlen(recvBuff), 0);
                     if(byte_size <0){
                        send(connfd, "404 : Not Found\n", 16, 0);
                        errorType = "404 : Not Found";
                        proxyAction = "Connection Closed";
                        badRequestFlag = 1;
                        reqErrorFlag = 0;
                        goto closed;
                     }
                     //fprintf(stdout, "\nI got something longer than 500 bytes, count = %d\n ", count);
                     count -= 500;
                  }
               }
               
               
               /*______________________________Server to Browser__________________________________*/
               //if there is reply to server
               if(FD_ISSET(newsocket, &rwset)){
               
                  //recv and send over data
                  do{
                     //init and recv data from server
                     memset(recvBuff, '0',500);
                     byte_size = recv(newsocket, recvBuff, 500, 0);
                     
                     //if there is data send it over
                     if(byte_size>0){
                        byte_size = send(connfd, recvBuff, byte_size, 0);
                        
                        //handle the error if sending failed
                        if(byte_size <0){
                           send(connfd, "404 : Not Found\n", 16, 0);
                           errorType = "404 : Not Found";
                           proxyAction = "Connection Closed";
                           badRequestFlag = 1;
                           reqErrorFlag = 0;
                           goto closed;
                        }
                        
                     //if recvied 0 bytes, close connection   
                     }else if(byte_size == 0){
                        goto beforeClosed;
                     }
                  }while(byte_size > 0);  //do this until no data was recved and sended
                  
               }
            }
            
            //error log update and close connection
beforeClosed:               
            errorType = "N/A";
            proxyAction = "Request Forwarded";
            
            //close connection
closed:                     
            fprintf(stdout, "Connection Closed\n");
            close(connectFlag);
            close(newsocket);
            
         }else{
         //when the HTTP request from the if statement above did not match, handle that error
            if(reqErrorFlag){
               send(connfd, "400 : BAD REQUEST\n", 18, 0);
               errorType = "400 : BAD REQUEST";
               proxyAction = "Rejected Bad Request";
               badRequestFlag = 1;
               reqErrorFlag = 0;
            }
         }
            
            
         /**************************Logging Traffics********************************/
         //if can not open log file, 
         if((loggingChild = fopen("logging.txt", "a"))== NULL){                                          
            fprintf(stderr,"ERROR: Unable to open log file in child process\n");
         }else{
         //if file can be open, but header is not right, log action and error
            if(badRequestFlag){
               fprintf(loggingChild,
                  "Time: %sType of Request: N/A\r\nHTTP: N/A\r\nHost: N/A\r\nURI: N/A\r\nServer Address: N/A\r\nProxy Action: %s\r\nError: %s\r\n\r\n"
                     ,asctime(timeinfo),proxyAction,errorType);
            }else{
         //if header is understable, log request
               fprintf(loggingChild,
                  "Time: %sType of Request: %s\r\nHTTP: %s\r\nHost: %s\r\nURI: %s\r\nServer Address: %s\r\nProxy Action: %s\r\nError: %s\r\n\r\n"
                     ,asctime(timeinfo),method,protocol,host_name,host_path,inet_ntoa(host_addr.sin_addr),proxyAction,errorType);
            }
         }
         //close writing fd to log file
         fclose(loggingChild);
         
         //exit child successfully
         exit(0);
      }
      //close browser connection
      close(connfd);
   }
   
   //close listening socket
   close(listenfd);

   return 0;
}
