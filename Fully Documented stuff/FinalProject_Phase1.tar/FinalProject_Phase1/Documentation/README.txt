README

Name: Yu Yin Guan
Email: yguan5@ucsc.edu
Section: Wednesday 4PM - 6PM
Date: 5/30/2014
Assignment: Final Project Phase 1

File Descriptions:

   Documentation:
      - StateMachine.pdf               A state machine of my proxy  
      - Documenation.pdf               A discription of what/why/how I wrote the proxy
      - README:                        Notes and description of what is in these files
      
   Source:
      - proxy.c:                       main code of my proxy
      - Makefile:                      creates binaries for proxy.c when command "make" is entered, "make clean" will clean the object files
      - permitted_sites.txt:           Contain a list of sites allowed, sites not on this document is filtered 
      - logging.txt                    File created with each start of the proxy, contains information of the traffic during the time proxy is on. 
                                       Reset and discards everything when proxy is restarted
   
Instructions:
   -  Run make to create the object files Client and Server.
   -  To run the program for this proxy:   ./proxy <port>
   -  feel free to add new sites of access in permitted_sites.txt, each site needs a new line
   
Note:
   - Did not test HEAD method because I did not know how to generate that request through browser
   - Websites looks a bit off because of the filtering of websites, since they take pictures off of other websites
   - The filter can be taken out with the commenting of the filter chunk of code specified in the code, should allow most websites to look normal
   - When make proxy, this warning will appear which I have no idea why:
      proxy.c:128:10: warning: statement with no effect [-Wunused-value]
      proxy.c:129:10: warning: statement with no effect [-Wunused-value]

   
Tested:
   NOTE: ALL THESE TEST ARE DONE IN THE LASTEST VERSION OF FIREFOX
   
      - When to www.google.com and is able to search through the engine
      - Tested GET method with all the sites that is preloaded on the permitted_sites.txt
      - Tested POST method with log on to google, posting with www.randomwebsite.com and www.hurl.it
      - Closing browser midway of connection and restarting it
      - Clicking on other links on the web, only allows sites are accessible, clicking links to other sites not allowed will return 403 : FORBIDDEN URL
      - Entering sites not on permitted_sites file will give 403 : FORBIDDEN URL
      
Error:
   - The logging file sometimes does not log all the traffic, if persistance connection occurs. P.S logging happens at the end of connections
   - Sometimes connection hangs but I can not figure out why
   - The timestamps of the log file in each traffic is off in 2 dates, 3 month, 1 years, 11 hours, 15 minutes. 
     The time is consistent, I just can't get the offset to the right time. 
   - can log into google account, but hangs sometimes
