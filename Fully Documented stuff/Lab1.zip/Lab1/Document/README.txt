Name: Yu Yin Guan

FILES:

   Client.c - The c code for client side of the TCP
   Server.c - The c code for the server side of the TCP
   Makefile - file used to gcc the client and server file
   Documentation - Description to protocols and results of the program
   
   