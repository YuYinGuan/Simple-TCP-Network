README

Name: Yu Yin Guan
Email: yguan5@ucsc.edu
Section: Wednesday 4PM - 6PM
Date: 5/30/2014
Assignment: Final Project Phase 1

File Descriptions:

   Documentation:
      - StateMachine.pdf               A state machine of my proxy with SSL  
      - Documenation.pdf               A description of what/why/how I wrote the proxy
      - README:                        Notes and description of what is in these files
      
   Source:
      - proxy.c:                       main code of my proxy
      - Makefile:                      creates binaries for proxy.c when command "make" is entered, "make clean" will clean the object files
      - permitted_sites.txt:           Contain a list of sites allowed, sites not on this document is filtered 
      - logging.txt                    File created with each start of the proxy, contains information of the traffic during the time proxy is on. 
                                       Reset and discards everything when proxy is restarted
   
Instructions:
   -  Run make to create the object files Client and Server.
   -  To run the program for this proxy:   ./proxy <port>
   -  feel free to add new sites of access in permitted_sites.txt, each site needs a new line
   - To run my program, please erase history because client init SSL does not work on my program and browsers will auto change to SSL if there was history
   - Run the proxy and type in the website with the https, the redirect message will initialize a SSL connection attempt
   
Note:
   - This program does not quite work. The reason being that it can not connect in SSL with some of the https websites, but there are ones that do
   - The one that I can actually connect to is in the permitted_sites.txt under the name www.httpsnow.org
   - I did my program base on redirect response from websites. I did not implement client initializing SSL. Check State machine for detail.
   - I got stuck on this bug for too long, can't figure it out
   
Tested:
   NOTE: ALL THESE TEST ARE DONE IN THE LASTEST VERSION OF FIREFOX
   
      - Tested with random https websites on the bottom of the permitted_sites.txt. Only the one with www.httpsnow.org kind of works.
      - Tested with websites like www.google.com, it did not connect
      - Tested with websites such as www.sifterapp.com
      - Some websites will connect with SSL but I can't access the contain for some reason, I can see in the code that it is transfering stuff
      - Some websites like google will just plainly not connect
      
      - The code is messy, I was trying to finish code so I didn't comment too much or clean up, sorry
      
Error:
   - The logging file sometimes does not log all the traffic, if persistance connection occurs. P.S logging happens at the end of connections
   - Sometimes connection hangs but I can not figure out why
   - The timestamps of the log file in each traffic is off in 2 dates, 3 month, 1 years, 11 hours, 15 minutes. 
     The time is consistent, I just can't get the offset to the right time. 
   - can log into google account, but hangs sometimes
   
   SSL: ERROR
   - did debugging for the error that I get is 
         3078358672:error:2006A066:BIO routines:BIO_get_host_ip:bad hostname lookup:b_sock.c:149:host=www.www.google.com
      I find that most of the time, if the redirect response came back with and URI like www.google.com/something something, it will not connect
         I just attach the port at the back of the URL/URI and put it in the following:
               BIO_set_conn_hostname(bio, "hostname:port");

